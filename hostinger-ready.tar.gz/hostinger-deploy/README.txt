LEARNHUB - HOSTINGER DEPLOYMENT PACKAGE
========================================

1. UPLOAD THIS FOLDER to Hostinger (zip or tar.gz)

2. SET ENVIRONMENT VARIABLES in Hostinger panel:
   NODE_ENV=production
   PORT=3000
   STATIC_PATH=./public
   SESSION_SECRET=your_value
   SUPABASE_URL=your_value
   SUPABASE_SERVICE_ROLE_KEY=your_value
   SUPABASE_ANON_KEY=your_value

3. START COMMAND: node dist/index.mjs
   (or use package.json "start" script)

4. Framework: Express
   Entry point: dist/index.mjs
   Node version: 20+

NO npm install needed - all dependencies are bundled inside dist/index.mjs
