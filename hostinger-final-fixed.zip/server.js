'use strict';
// LearnHub — Hostinger Node.js Entry Point
// CommonJS format: maximum compatibility with all Node.js 20+ hosts

const fs = require('fs');
const path = require('path');

// ── Environment defaults (Hostinger panel vars take priority) ──────────────
process.env.NODE_ENV    = process.env.NODE_ENV    || 'production';
process.env.PORT        = process.env.PORT        || '3000';
process.env.STATIC_PATH = process.env.STATIC_PATH || './dist';

// ── Load .env file if present ──────────────────────────────────────────────
const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile)) {
  const lines = fs.readFileSync(envFile, 'utf8').split('\n');
  for (const line of lines) {
    const clean = line.trim();
    if (!clean || clean.startsWith('#')) continue;
    const eq = clean.indexOf('=');
    if (eq < 1) continue;
    const key = clean.slice(0, eq).trim();
    const val = clean.slice(eq + 1).trim();
    if (key && !process.env[key]) process.env[key] = val;
  }
}

console.log('[LearnHub] Starting on PORT=' + process.env.PORT);
console.log('[LearnHub] Static files from: ' + process.env.STATIC_PATH);
console.log('[LearnHub] NODE_ENV: ' + process.env.NODE_ENV);

// ── Boot compiled Express server (ES module via dynamic import) ────────────
import('./api/index.mjs').catch(function(err) {
  console.error('[LearnHub] FATAL startup error:', err.message || err);
  process.exit(1);
});
