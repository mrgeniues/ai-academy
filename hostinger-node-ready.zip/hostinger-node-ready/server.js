// LearnHub - Entry Point for Hostinger Node.js Hosting
// Sets required environment defaults then boots the compiled Express server

// Default environment values (override via .env or Hostinger panel)
process.env.NODE_ENV   = process.env.NODE_ENV   || 'production';
process.env.PORT       = process.env.PORT       || '3000';
process.env.STATIC_PATH = process.env.STATIC_PATH || './dist';

// Load .env file if present (Hostinger injects vars via panel, .env is fallback)
import { readFileSync, existsSync } from 'fs';
if (existsSync('./.env')) {
  const lines = readFileSync('./.env', 'utf8').split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const val = trimmed.slice(eq + 1).trim();
    if (key && !process.env[key]) process.env[key] = val;
  }
}

// Boot the compiled Express + API server
await import('./api/index.mjs');
