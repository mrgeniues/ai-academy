// LearnHub — Hostinger Node.js Entry Point
// Framework: Express  |  Node >= 20

// Set safe defaults before booting (Hostinger panel vars override these)
process.env.NODE_ENV    = process.env.NODE_ENV    || 'production';
process.env.PORT        = process.env.PORT        || '3000';
process.env.STATIC_PATH = process.env.STATIC_PATH || './dist';

// Load .env file if present (fallback for local testing)
import { existsSync, readFileSync } from 'fs';
if (existsSync('./.env')) {
  for (const line of readFileSync('./.env', 'utf8').split('\n')) {
    const clean = line.trim();
    if (!clean || clean.startsWith('#')) continue;
    const eq = clean.indexOf('=');
    if (eq < 1) continue;
    const key = clean.slice(0, eq).trim();
    const val = clean.slice(eq + 1).trim();
    if (key && !process.env[key]) process.env[key] = val;
  }
}

// Boot the compiled Express server (all routes + static serving inside)
await import('./api/index.mjs');
