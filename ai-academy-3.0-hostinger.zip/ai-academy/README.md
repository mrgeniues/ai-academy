# AI Academy 3.0 — Hostinger Deployment Guide

## Folder Structure
```
ai-academy/
├── dist/          ← compiled Node.js server (do NOT modify)
├── public/        ← compiled React frontend (do NOT modify)
├── package.json
├── .env           ← your environment variables (create from .env.example)
└── README.md
```

## Hostinger Node.js Hosting Setup

### Step 1 — Upload Files
Upload all files to your Hostinger Node.js application root via FTP or the File Manager.

### Step 2 — Set Environment Variables
In Hostinger hPanel → Node.js → your app → Environment Variables, add:

| Key | Value |
|-----|-------|
| `NODE_ENV` | `production` |
| `PORT` | *(leave blank — Hostinger assigns it)* |
| `STATIC_PATH` | `./public` |
| `SUPABASE_URL` | your Supabase project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | your Supabase service role key |
| `SUPABASE_ANON_KEY` | your Supabase anon key |
| `SESSION_SECRET` | a long random string (min 32 chars) |
| `RESEND_API_KEY` | your Resend API key (for password reset emails) |
| `SITE_URL` | your domain e.g. `https://yourdomain.com` |

### Step 3 — Configure Node.js App
In Hostinger hPanel → Node.js, set:
- **Node.js version:** 18 or higher
- **Application root:** the folder you uploaded to
- **Application startup file:** `dist/index.mjs`

### Step 4 — Start the App
Click "Start" in hPanel → Node.js. Your app will be live on your domain.

## Demo Login Credentials
| Email | Password | Role |
|-------|----------|------|
| admin@lms.com | password123 | Admin |
| alice@example.com | password123 | Creator |
| bob@example.com | password123 | Member |

## Database Setup
If you haven't run the SQL setup yet, paste `supabase-setup.sql` into your Supabase SQL Editor.

## Troubleshooting
- **App not loading:** Make sure `NODE_ENV=production` is set and `STATIC_PATH=./public`
- **API errors:** Check that all Supabase environment variables are correct
- **Login fails:** Make sure `SESSION_SECRET` is set to a stable value (don't change it after users sign up)
